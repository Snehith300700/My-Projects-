# Walmart Sales Playbook : Data analysis for retail success
# Capstone Project Phase-2 R Part 
# Group members: Haveela, Aarushi, Snehith

# Loading and importing the  necessary libraries
library(dplyr)
library(ggplot2)
library(lubridate)
library(caret)
library(randomForest)
library(cluster)
library(tidyverse)
library(fpp3)
library(stats)
library(openxlsx)
library(pROC)
library(data.table)

# Importing and viewing the final datasets
features <- read.csv("D:/SEMESTER IV/Business Capstone/Capstone Project/WALMART SALES PLAYBOOK  - DATA ANALYSIS FOR RETAIL SUCCESS/features.csv")
view(features)

stores <- read.csv("D:/SEMESTER IV/Business Capstone/Capstone Project/WALMART SALES PLAYBOOK  - DATA ANALYSIS FOR RETAIL SUCCESS/stores.csv")
view(stores)

# Converting  Date column to Date type and extract "year" and "month" columns

features$Date <- mdy(features$Date)
features$Year <- year(features$Date)
features$Month <- months(features$Date)


# Merging the "features" and "stores" dataset for better understanding and analysis and naming it as "Sales"
Sales <- merge(features, stores, by = "Store")
view(Sales)

# Exporting the combined dataset "Sales.csv" to local path as ".xslx" file
write.xlsx(Sales, "Sales.xlsx")

# Data cleaning and Preprocessing
# Exploring the structure of the dataset
str(Sales)

# Examining the summary of the dataset 
summary(Sales)

# checking for count of missing values
sum(is.na(Sales))

# Setting seed for reproducibility 
set.seed(123)

# Saving Sales data into new variable called "data"
write.csv(Sales, "Sales.csv")

View("Sales.csv")

data <- read.csv("Sales.csv")
View(data)

data$IsHoliday <- ifelse(data$IsHoliday == TRUE, 1, 0)
data$Type <- ifelse(data$Type == "A", 1,
                    ifelse(data$Type == "B", 2, 3))
data$Month <- match(data$Month, month.name)

as.factor(IsHoliday) ~ Weekly_Sales + Month + Year

View(data)

write.csv(data, "Modified_Sales.csv")

View("Modified_Sales.csv")

# Dividing the "Sales.csv" into training and testing datasets in the ratio of 80:20
trainIndex <- createDataPartition(data$IsHoliday, p = 0.8, list = FALSE)
trainData <- data[trainIndex, ]
testData <- data[-trainIndex, ]

#( 5472 objects in training dataset and 1368 objects in testing dataset)

# Applying Models for all the four hypothesis

#Hypothesis-1 : Are there certain holidays or times of year that consistently drive higher sales?

# Set seed for reproducibility
set.seed(123)

# Load the data
holiday_data <- data %>%
  select(Weekly_Sales, IsHoliday, Month, Year)

holiday_data$cluster <- as.factor(holiday_data$IsHoliday)

sum(is.na(holiday_data))

view(holiday_data)
# Split into training and testing sets
set.seed(123)
train_index <- createDataPartition(holiday_data$Weekly_Sales, p = 0.8, list = FALSE)
train_datah <- holiday_data[train_index, ]
test_datah <- holiday_data[-train_index, ]

# Applying Random Forest for H-1
library(randomForest)
rf_model <- randomForest(Weekly_Sales ~ IsHoliday, data = train_datah)
predictions <- predict(rf_model, newdata = test_datah)

# Evaluate
rf_rmse <- sqrt(mean((predictions - test_datah$Weekly_Sales)^2))
print(paste("Random Forest RMSE:", rf_rmse))

library(plotly)

plot_ly(test_datah, x = ~Weekly_Sales, y = ~IsHoliday, color = ~cluster, type = 'scatter')

write.csv(holiday_data, "Holiday_Clusters.csv")

# Hypothesis-2: How do changes in temperature and weather patterns affect customer behavior and purchasing decisions?

# Preparing the temparature data
temperature_data <- data[, c("Weekly_Sales", "Temperature")]

# Split into training and testing sets
set.seed(123)
train_index <- createDataPartition(temperature_data$Weekly_Sales, p = 0.8, list = FALSE)
train_data <- temperature_data[train_index, ]
test_data <- temperature_data[-train_index, ]

# Applying Linear Regression model for H-2
lm_model <- lm(Weekly_Sales ~ Temperature, data = train_data)
predictions <- predict(lm_model, newdata = test_data)

# Evaluate
lm_rmse <- sqrt(mean((predictions - test_data$Weekly_Sales)^2))
print(paste("Linear Regression RMSE:", lm_rmse))

# Plot predictions vs actual

ggplot(test_data, aes(x = Temperature, y = Weekly_Sales)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Temperature vs Weekly Sales", x = "Temperature", y = "Weekly Sales")

write.csv(test_data, "Temperature_Sales.csv")

# Hypothesis-3: To what extent do fluctuations in fuel prices impact customer spending, particularly on products related to transportation or outdoor activities?

fuel_data <- data[, c("Weekly_Sales", "Fuel_Price")]

# Split into training and testing sets
set.seed(123)
train_index <- createDataPartition(fuel_data$Weekly_Sales, p = 0.8, list = FALSE)
train_data2 <- fuel_data[train_index, ]
test_data2 <- fuel_data[-train_index, ]

# Applying Random Forest for H-3
library(randomForest)
rf_model <- randomForest(Weekly_Sales ~ Fuel_Price, data = train_data2)
predictions <- predict(rf_model, newdata = test_data2)

# Evaluate
rf_rmse <- sqrt(mean((predictions - test_data2$Weekly_Sales)^2))
print(paste("Random Forest RMSE:", rf_rmse))

# Plot predictions vs actual
ggplot(test_data2, aes(x = Fuel_Price, y = predictions)) +
  geom_point(color = "orange") +
  labs(title = "Predicted Sales vs Weekly Sales (Random Forest)", x = "Weekly Sales", y = "Predicted Sales") +
  theme_minimal()

write.csv(test_data2, "Fuel_Sales.csv")

# Hypothesis-4: 4.Are there specific economic indicators (e.g., unemployment rates) that correlate with changes in store sales?

# Prepare data
economic_data <- data[, c("Weekly_Sales", "Unemployment", "CPI")]

# Split into training and testing sets
set.seed(123)
train_index <- createDataPartition(economic_data$Weekly_Sales, p = 0.8, list = FALSE)
train_data3 <- economic_data[train_index, ]
test_data3 <- economic_data[-train_index, ]

# Multiple Regression
multi_lm_model <- lm(Weekly_Sales ~ Unemployment + CPI, data = train_data3)
predictions <- predict(multi_lm_model, newdata = test_data3)

# Evaluate
multi_rmse <- sqrt(mean((predictions - test_data3$Weekly_Sales)^2))
print(paste("Multiple Regression RMSE:", multi_rmse))

# Plot predictions vs actual
# Visualize Predictions
ggplot(test_data3, aes(x = Unemployment, y = Weekly_Sales)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Unemployment vs Weekly Sales", x = "Unemployment Rate", y = "Weekly Sales")


write.csv(test_data, "Economic_Sales.csv")




# Load the data
holiday_data <- read.csv("Holiday_Clusters.csv")

